/*
 * utils.h
 *
 *  Created on: 2011-08-27
 *      Author: francis
 */

#ifndef UTILS_H_
#define UTILS_H_

int gettid();

#endif /* UTILS_H_ */
